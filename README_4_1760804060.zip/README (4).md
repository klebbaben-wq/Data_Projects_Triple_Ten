
README.md

# Superstore Profitability Analysis

## Project Overview
This Tableau dashboard analyzes profitability, advertising strategy, and return behavior for a struggling superstore.

## Key Insights
- Identified top profit and loss centers by product and region.
- Recommended advertising strategy based on seasonal and geographic trends.
- Analyzed return rates to suggest operational improvements.

## Dashboard Link
[View my Tableau Dashboard] https://public.tableau.com/views/Superstore_17605820289350/Top2Profit?:language=en-US&publish=yes&:sid=&:redirect=auth&:display_count=n&:origin=viz_share_link

## Files Included
- README.md
- Superstore Dashboard (.twbx)
- Superstore.xls


