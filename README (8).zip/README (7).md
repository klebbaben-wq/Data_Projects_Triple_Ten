
Return Analysis

This Tableau dashboard analyzes the return rate on products for a superstore and facilitates better understanding on what might be causing those returns.

https://public.tableau.com/app/profile/ben.klebba/viz/AnalysisonReturns_17616036669630/CorrelationbetweenTotalSalesandTotalReturn?publish=yes

